package com.dare.videoQuery.dao;

import com.dare.videoQuery.model.VideoObject;
import org.springframework.stereotype.Repository;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;


@Repository("videoDao")
public class VideoAccessService implements EditResultDao, DisplayResultDao {

    private static final List<VideoObject> ObjectList = new ArrayList<>();
    private static  List<VideoObject> ObjectList1 = new ArrayList<>();
    private static List<Path> FrameList = new ArrayList<Path>();


    @Override
    public int editVideoResult(int objectId, String objectType, int objectTypeCode) {
        for (VideoObject videoObject : ObjectList1) {
            if (videoObject.getObjectId() == objectId) {
                videoObject.setObjectType(objectType);
                videoObject.setObjectTypeCode(objectTypeCode);
            }
        }

        return 1;
    }

    @Override
    public List getVideoResult() throws FileNotFoundException {
        String desktop = System.getProperty ("user.home") + "/Desktop/";
        Scanner scan = new Scanner(new File(desktop + "img01146.jpg.txt"));

        while (scan.hasNextLine()) {
            int objectId, objectTypeCode;
            double score;
            String objectType, coordinates,line;
            line = scan.nextLine();
            String[] strArray = line.split(";");
            System.out.println(strArray);
            objectId = Integer.parseInt(strArray[0]);
            objectType = strArray[1].trim();
            objectTypeCode = Integer.parseInt(strArray[2].trim());
            coordinates = strArray[3].trim();
            score = Double.parseDouble(strArray[4].trim());
            VideoObject object1 = new VideoObject(objectId, objectType, objectTypeCode, coordinates, score);
            ObjectList.add(object1);


        }
        return ObjectList;
    }

    @Override
    public int createList() throws FileNotFoundException {
        String desktop = System.getProperty ("user.home") + "/Desktop/";
        Scanner scan = new Scanner(new File(desktop + "img01146.jpg.txt"));

        while (scan.hasNextLine()) {
            int objectId, objectTypeCode;
            double score;
            String objectType, coordinates, line;
            line = scan.nextLine();
            String[] strArray = line.split(";");
            objectId = Integer.parseInt(strArray[0]);
            objectType = strArray[1].trim();
            objectTypeCode = Integer.parseInt(strArray[2].trim());
            coordinates = strArray[3].trim();
            score = Double.parseDouble(strArray[4].trim());
            VideoObject object1 = new VideoObject(objectId, objectType, objectTypeCode, coordinates, score);
            ObjectList1.add(object1);

        }
        return 1;
    }

    @Override
    public List getNewResult() {
        return ObjectList1;
    }

    @Override
    public List leaseVideo() {
       try(Stream<Path> paths = Files.walk(Paths.get("/Users/user/Downloads/v6/frames"))) {
           paths.forEach(filePath ->{
               if(Files.isRegularFile(filePath)){
                 try {
                    FrameList.add(filePath);
                 } catch (Exception e ){
                     e.printStackTrace();
                 }
               }
           });

       } catch (IOException e){
           e.printStackTrace();
       }

        Collections.sort(FrameList);

        return FrameList;
    }
}