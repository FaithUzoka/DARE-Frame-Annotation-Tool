package com.dare.videoQuery.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class VideoObject {
    private int objectTypeCode;
    private final int objectId;
    private final double score;
    private String objectType, coordinates;

    public VideoObject(@JsonProperty("objectId") int objectId, String objectType, @JsonProperty("objectTypeCode") int objectTypeCode, String coordinates, double score) {
        this.objectTypeCode = objectTypeCode;
        this.objectType = objectType;
        this.objectId = objectId;
        this.coordinates = coordinates;
        this.score = score;
    }

    public int getObjectTypeCode() {
        return objectTypeCode;
    }

    public int getObjectId(){
        return objectId;
    }

    public String getObjectType(){
        return objectType;
    }

    public String getCoordinates(){return coordinates;}

    public double getScore(){return score;}

    public void setObjectType(String type){
        objectType = type;
    }

    public void setObjectTypeCode(int typeCode){objectTypeCode = typeCode;};

}
