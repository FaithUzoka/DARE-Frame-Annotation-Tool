package com.dare.videoQuery.correctedDisplayAPI;
import com.dare.videoQuery.model.VideoObject;
import com.dare.videoQuery.service.CorrectedDisplayService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.FileNotFoundException;
import java.util.List;

@RequestMapping("correctedDisplayAPI/v1/videoObject")
@RestController
public class CorrectedDisplayController {

    @Autowired
    public CorrectedDisplayController(CorrectedDisplayService correctedDisplayService) {
    }

    @PutMapping
    public int createList() throws FileNotFoundException {
        return CorrectedDisplayService.createList();
    }

    @GetMapping
    public List getNewResult(){
        return CorrectedDisplayService.getNewResult();
    }

}
